﻿namespace WinFormsApp11
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            textBoxUsername = new TextBox();
            textBoxPassword = new TextBox();
            labelStatus = new Label();
            pictureBox1 = new PictureBox();
            rjButton1 = new CustomControls.RJControls.RJButton();
            buttonLogin = new CustomControls.RJControls.RJButton();
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // textBoxUsername
            // 
            textBoxUsername.Location = new Point(231, 173);
            textBoxUsername.Name = "textBoxUsername";
            textBoxUsername.Size = new Size(222, 23);
            textBoxUsername.TabIndex = 0;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(231, 225);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(222, 23);
            textBoxPassword.TabIndex = 1;
            textBoxPassword.UseSystemPasswordChar = true;
            // 
            // labelStatus
            // 
            labelStatus.AutoSize = true;
            labelStatus.Location = new Point(115, 103);
            labelStatus.Name = "labelStatus";
            labelStatus.Size = new Size(0, 15);
            labelStatus.TabIndex = 3;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(-1, -136);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(665, 303);
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // rjButton1
            // 
            rjButton1.BackColor = Color.FromArgb(0, 64, 0);
            rjButton1.BackgroundColor = Color.FromArgb(0, 64, 0);
            rjButton1.BorderColor = Color.PaleVioletRed;
            rjButton1.BorderRadius = 10;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic);
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(216, 267);
            rjButton1.Name = "rjButton1";
            rjButton1.Size = new Size(113, 40);
            rjButton1.TabIndex = 6;
            rjButton1.Text = "Зарегать";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // buttonLogin
            // 
            buttonLogin.BackColor = Color.FromArgb(0, 64, 0);
            buttonLogin.BackgroundColor = Color.FromArgb(0, 64, 0);
            buttonLogin.BorderColor = Color.PaleVioletRed;
            buttonLogin.BorderRadius = 10;
            buttonLogin.BorderSize = 0;
            buttonLogin.FlatAppearance.BorderSize = 0;
            buttonLogin.FlatStyle = FlatStyle.Flat;
            buttonLogin.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic);
            buttonLogin.ForeColor = Color.White;
            buttonLogin.Location = new Point(355, 267);
            buttonLogin.Name = "buttonLogin";
            buttonLogin.Size = new Size(118, 40);
            buttonLogin.TabIndex = 7;
            buttonLogin.Text = "Войти";
            buttonLogin.TextColor = Color.White;
            buttonLogin.UseVisualStyleBackColor = false;
            buttonLogin.Click += rjButton2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(173, 176);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 8;
            label1.Text = "Логин:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(165, 228);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 9;
            label2.Text = "Пароль:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(663, 402);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonLogin);
            Controls.Add(rjButton1);
            Controls.Add(pictureBox1);
            Controls.Add(labelStatus);
            Controls.Add(textBoxPassword);
            Controls.Add(textBoxUsername);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "BANK";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxUsername;
        private TextBox textBoxPassword;
        private Label labelStatus;
        private PictureBox pictureBox1;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJButton buttonLogin;
        private Label label1;
        private Label label2;
    }
}
