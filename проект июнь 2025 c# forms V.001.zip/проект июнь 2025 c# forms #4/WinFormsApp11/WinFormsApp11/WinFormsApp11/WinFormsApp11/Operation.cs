﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp11
{
    class Operation
    {
        public DateTime Date { get; set; }
        public string Type { get; set; } // например, "Перевод", "Пополнение"
        public decimal Amount { get; set; }
        public decimal BalanceAfter { get; set; }
        public string Description { get; set; }
    }
}
