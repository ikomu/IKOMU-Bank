﻿namespace WinFormsApp11
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminForm));
            listBoxUsers = new ListBox();
            buttonItems = new CustomControls.RJControls.RJButton();
            buttonTransactions = new CustomControls.RJControls.RJButton();
            buttonUsers = new CustomControls.RJControls.RJButton();
            SuspendLayout();
            // 
            // listBoxUsers
            // 
            listBoxUsers.BackColor = Color.White;
            listBoxUsers.FormattingEnabled = true;
            listBoxUsers.ItemHeight = 15;
            listBoxUsers.Location = new Point(6, 8);
            listBoxUsers.Name = "listBoxUsers";
            listBoxUsers.Size = new Size(175, 154);
            listBoxUsers.TabIndex = 0;
            // 
            // buttonItems
            // 
            buttonItems.BackColor = Color.FromArgb(192, 0, 0);
            buttonItems.BackgroundColor = Color.FromArgb(192, 0, 0);
            buttonItems.BorderColor = Color.PaleVioletRed;
            buttonItems.BorderRadius = 15;
            buttonItems.BorderSize = 0;
            buttonItems.FlatAppearance.BorderSize = 0;
            buttonItems.FlatStyle = FlatStyle.Flat;
            buttonItems.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonItems.ForeColor = Color.White;
            buttonItems.Location = new Point(210, 22);
            buttonItems.Name = "buttonItems";
            buttonItems.Size = new Size(150, 40);
            buttonItems.TabIndex = 1;
            buttonItems.Text = "items.json";
            buttonItems.TextColor = Color.White;
            buttonItems.UseVisualStyleBackColor = false;
            buttonItems.Click += buttonItems_Click;
            // 
            // buttonTransactions
            // 
            buttonTransactions.BackColor = Color.FromArgb(192, 0, 0);
            buttonTransactions.BackgroundColor = Color.FromArgb(192, 0, 0);
            buttonTransactions.BorderColor = Color.PaleVioletRed;
            buttonTransactions.BorderRadius = 15;
            buttonTransactions.BorderSize = 0;
            buttonTransactions.FlatAppearance.BorderSize = 0;
            buttonTransactions.FlatStyle = FlatStyle.Flat;
            buttonTransactions.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonTransactions.ForeColor = Color.White;
            buttonTransactions.Location = new Point(210, 68);
            buttonTransactions.Name = "buttonTransactions";
            buttonTransactions.Size = new Size(150, 40);
            buttonTransactions.TabIndex = 2;
            buttonTransactions.Text = "transactions.json";
            buttonTransactions.TextColor = Color.White;
            buttonTransactions.UseVisualStyleBackColor = false;
            buttonTransactions.Click += buttonTransactions_Click;
            // 
            // buttonUsers
            // 
            buttonUsers.BackColor = Color.FromArgb(192, 0, 0);
            buttonUsers.BackgroundColor = Color.FromArgb(192, 0, 0);
            buttonUsers.BorderColor = Color.PaleVioletRed;
            buttonUsers.BorderRadius = 15;
            buttonUsers.BorderSize = 0;
            buttonUsers.FlatAppearance.BorderSize = 0;
            buttonUsers.FlatStyle = FlatStyle.Flat;
            buttonUsers.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonUsers.ForeColor = Color.White;
            buttonUsers.Location = new Point(210, 114);
            buttonUsers.Name = "buttonUsers";
            buttonUsers.Size = new Size(150, 40);
            buttonUsers.TabIndex = 3;
            buttonUsers.Text = "users.json";
            buttonUsers.TextColor = Color.White;
            buttonUsers.UseVisualStyleBackColor = false;
            buttonUsers.Click += buttonUsers_Click;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(402, 174);
            Controls.Add(buttonUsers);
            Controls.Add(buttonTransactions);
            Controls.Add(buttonItems);
            Controls.Add(listBoxUsers);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AdminForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin-Panel";
            ResumeLayout(false);
        }

        #endregion

        private ListBox listBoxUsers;
        private CustomControls.RJControls.RJButton buttonItems;
        private CustomControls.RJControls.RJButton buttonTransactions;
        private CustomControls.RJControls.RJButton buttonUsers;
    }
}