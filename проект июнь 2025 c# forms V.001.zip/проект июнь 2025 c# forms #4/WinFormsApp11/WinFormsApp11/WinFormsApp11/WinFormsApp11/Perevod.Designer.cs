﻿namespace WinFormsApp11
{
    partial class Perevod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFromUsername = new TextBox();
            txtToUsername = new TextBox();
            txtAmount = new TextBox();
            btnTransfer = new Button();
            lblResult = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            SuspendLayout();
            // 
            // txtFromUsername
            // 
            txtFromUsername.Location = new Point(169, 49);
            txtFromUsername.Name = "txtFromUsername";
            txtFromUsername.Size = new Size(100, 23);
            txtFromUsername.TabIndex = 0;
            // 
            // txtToUsername
            // 
            txtToUsername.Location = new Point(169, 95);
            txtToUsername.Name = "txtToUsername";
            txtToUsername.Size = new Size(100, 23);
            txtToUsername.TabIndex = 1;
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(169, 152);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(100, 23);
            txtAmount.TabIndex = 2;
            // 
            // btnTransfer
            // 
            btnTransfer.Location = new Point(169, 210);
            btnTransfer.Name = "btnTransfer";
            btnTransfer.Size = new Size(75, 23);
            btnTransfer.TabIndex = 3;
            btnTransfer.Text = "button1";
            btnTransfer.UseVisualStyleBackColor = true;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(186, 274);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(38, 15);
            lblResult.TabIndex = 4;
            lblResult.Text = "label1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(348, 98);
            label1.Name = "label1";
            label1.Size = new Size(193, 15);
            label1.TabIndex = 5;
            label1.Text = "Данная форма не используется!!!!";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(348, 122);
            label2.Name = "label2";
            label2.Size = new Size(193, 15);
            label2.TabIndex = 6;
            label2.Text = "Данная форма не используется!!!!";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(348, 152);
            label3.Name = "label3";
            label3.Size = new Size(193, 15);
            label3.TabIndex = 7;
            label3.Text = "Данная форма не используется!!!!";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(348, 184);
            label4.Name = "label4";
            label4.Size = new Size(193, 15);
            label4.TabIndex = 8;
            label4.Text = "Данная форма не используется!!!!";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(348, 218);
            label5.Name = "label5";
            label5.Size = new Size(193, 15);
            label5.TabIndex = 9;
            label5.Text = "Данная форма не используется!!!!";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(348, 249);
            label6.Name = "label6";
            label6.Size = new Size(193, 15);
            label6.TabIndex = 10;
            label6.Text = "Данная форма не используется!!!!";
            // 
            // Perevod
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblResult);
            Controls.Add(btnTransfer);
            Controls.Add(txtAmount);
            Controls.Add(txtToUsername);
            Controls.Add(txtFromUsername);
            Name = "Perevod";
            Text = "Perevod";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFromUsername;
        private TextBox txtToUsername;
        private TextBox txtAmount;
        private Button btnTransfer;
        private Label lblResult;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
    }
}