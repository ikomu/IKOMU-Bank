﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace WinFormsApp11
{
    public class TransactionManager
    {
        private const string FilePath = "transactions.json";

        public List<Transaction> Transactions { get; private set; } = new List<Transaction>();

        public TransactionManager()
        {
            LoadTransactions();
        }

        public void LoadTransactions()
        {
            if (File.Exists(FilePath))
            {
                try
                {
                    string json = File.ReadAllText(FilePath);
                    var loaded = JsonSerializer.Deserialize<List<Transaction>>(json);
                    if (loaded != null)
                        Transactions = loaded;
                }
                catch
                {
                    Transactions = new List<Transaction>();
                }
            }
        }

        public void SaveTransactions()
        {
            var json = JsonSerializer.Serialize(Transactions, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(FilePath, json);
        }

        public void AddTransaction(string username, decimal amount, string description)
        {
            var tx = new Transaction
            {
                Username = username,
                Amount = amount,
                Date = DateTime.Now,
                Description = description
            };
            Transactions.Add(tx);
            SaveTransactions();
        }

        public List<Transaction> GetUserTransactions(string username)
        {
            return Transactions.Where(t => t.Username == username).OrderByDescending(t => t.Date).ToList();
        }
    }
}
