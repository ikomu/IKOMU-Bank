﻿using System;
using System.IO;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class AdminForm : Form
    {
        private UserManager userManager;

        public AdminForm(UserManager userManager)
        {
            InitializeComponent();
            this.userManager = userManager;
            RefreshUserList();
        }

        private void RefreshUserList()
        {
            listBoxUsers.Items.Clear();
            foreach (var user in userManager.Users)
            {
                listBoxUsers.Items.Add($"{user.Username} ({user.Role})");
            }
        }

        private void buttonItems_Click(object sender, EventArgs e)
        {
            OpenJsonFile("items.json");
        }

        private void buttonTransactions_Click(object sender, EventArgs e)
        {
            OpenJsonFile("transactions.json");
        }

        private void buttonUsers_Click(object sender, EventArgs e)
        {
            OpenJsonFile("users.json");
        }

        private void OpenJsonFile(string fileName)
        {
            try
            {
                string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);

                if (!File.Exists(fullPath))
                {
                    MessageBox.Show($"Файл \"{fileName}\" не найден.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo()
                {
                    FileName = fullPath,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии файла \"{fileName}\": {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
