﻿using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class AccountForm : Form
    {
        private User currentUser;
        private UserManager userManager = new UserManager();
        private TransactionManager transactionManager = new TransactionManager();

        private const string ExchangeRateApiUrl = "https://www.cbr-xml-daily.ru/daily_json.js";

        public AccountForm(User user)
        {
            InitializeComponent();

            currentUser = user ?? throw new ArgumentNullException(nameof(user));

            labelWelcome.Text = $"Пользователь: {currentUser.Username}";

            this.Load += AccountForm_Load;

            // Запускаем загрузку курсов валют асинхронно (без блокировки UI)
            _ = LoadExchangeRates();
        }

        private void AccountForm_Load(object sender, EventArgs e)
        {
            UpdateBalance();
        }

        /// <summary>
        /// Метод обновляет отображение баланса из актуальных данных userManager
        /// </summary>
        private void UpdateBalance()
        {
            var user = userManager.Users.FirstOrDefault(u => u.Username == currentUser.Username);
            if (user != null)
            {
                currentUser = user;
                labelBalance.Text = $"Ваш баланс: {currentUser.Balance:C}";
            }
            else
            {
                labelBalance.Text = "Ваш баланс: N/A";
            }
        }

        private async Task LoadExchangeRates()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(ExchangeRateApiUrl);
                    response.EnsureSuccessStatusCode();

                    string json = await response.Content.ReadAsStringAsync();
                    JObject data = JObject.Parse(json);

                    decimal usdRate = (decimal)data["Valute"]["USD"]["Value"];
                    decimal eurRate = (decimal)data["Valute"]["EUR"]["Value"];
                    decimal aedRate = (decimal)data["Valute"]["AED"]["Value"];

                    // Обновляем UI через Invoke, если нужно (если вызывается не из UI-потока)
                    if (labelUsdRate.InvokeRequired)
                    {
                        labelUsdRate.Invoke(new Action(() => labelUsdRate.Text = $"USD: {usdRate:F2} руб."));
                        labelEurRate.Invoke(new Action(() => labelEurRate.Text = $"EUR: {eurRate:F2} руб."));
                        labelAedRate.Invoke(new Action(() => labelAedRate.Text = $"AED: {aedRate:F2} руб."));
                    }
                    else
                    {
                        labelUsdRate.Text = $"USD: {usdRate:F2} руб.";
                        labelEurRate.Text = $"EUR: {eurRate:F2} руб.";
                        labelAedRate.Text = $"AED: {aedRate:F2} руб.";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке курсов валют: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                labelUsdRate.Text = "USD: N/A";
                labelEurRate.Text = "EUR: N/A";
                labelAedRate.Text = "AED: N/A";
            }
        }

        /// <summary>
        /// Открываем форму пополнения баланса и подписываемся на событие закрытия, чтобы обновить баланс
        /// </summary>
        private void OpenBalancePlusForm()
        {
            var user = userManager.Users.FirstOrDefault(u => u.Username == currentUser.Username);
            if (user == null)
            {
                MessageBox.Show("Пользователь не найден");
                return;
            }

            var balancePlusForm = new BalancePlus(user, userManager);
            balancePlusForm.FormClosed += (s, e) => UpdateBalance();
            balancePlusForm.Show();
        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            var transferForm = new TransferForm(userManager, transactionManager);
            transferForm.FormClosed += (s, e) => UpdateBalance();
            transferForm.Show();
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            var storyForm = new Story(currentUser, transactionManager);
            storyForm.Show();
        }

        private void rjButton3_Click(object sender, EventArgs e)
        {
            Chatteh chatForm = new Chatteh();
            chatForm.Show();
        }

        private void rjButton4_Click(object sender, EventArgs e)
        {
            OpenBalancePlusForm();
        }

        private void rjButton5_Click(object sender, EventArgs e)
        {
            Settings settingsForm = new Settings();
            settingsForm.Show();
        }

        private void rjButton6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void rjButton7_Click(object sender, EventArgs e)
        {
            News newsForm = new News();
            newsForm.Show();
        }
    }
}
