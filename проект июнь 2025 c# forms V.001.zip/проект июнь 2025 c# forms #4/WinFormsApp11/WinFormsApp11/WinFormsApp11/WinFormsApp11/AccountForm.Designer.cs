﻿namespace WinFormsApp11
{
    partial class AccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AccountForm));
            labelWelcome = new Label();
            labelBalance = new Label();
            labelUsdRate = new Label();
            labelEurRate = new Label();
            labelAedRate = new Label();
            rjButton1 = new CustomControls.RJControls.RJButton();
            rjButton2 = new CustomControls.RJControls.RJButton();
            rjButton3 = new CustomControls.RJControls.RJButton();
            rjButton4 = new CustomControls.RJControls.RJButton();
            rjButton5 = new CustomControls.RJControls.RJButton();
            rjButton6 = new CustomControls.RJControls.RJButton();
            rjButton7 = new CustomControls.RJControls.RJButton();
            SuspendLayout();
            // 
            // labelWelcome
            // 
            labelWelcome.AutoSize = true;
            labelWelcome.Location = new Point(172, 18);
            labelWelcome.Name = "labelWelcome";
            labelWelcome.Size = new Size(41, 15);
            labelWelcome.TabIndex = 0;
            labelWelcome.Text = "label1";
            // 
            // labelBalance
            // 
            labelBalance.AutoSize = true;
            labelBalance.Location = new Point(12, 81);
            labelBalance.Name = "labelBalance";
            labelBalance.Size = new Size(41, 15);
            labelBalance.TabIndex = 1;
            labelBalance.Text = "label1";
            // 
            // labelUsdRate
            // 
            labelUsdRate.AutoSize = true;
            labelUsdRate.Location = new Point(12, 3);
            labelUsdRate.Name = "labelUsdRate";
            labelUsdRate.Size = new Size(34, 15);
            labelUsdRate.TabIndex = 8;
            labelUsdRate.Text = "USD:";
            // 
            // labelEurRate
            // 
            labelEurRate.AutoSize = true;
            labelEurRate.Location = new Point(12, 18);
            labelEurRate.Name = "labelEurRate";
            labelEurRate.Size = new Size(41, 15);
            labelEurRate.TabIndex = 9;
            labelEurRate.Text = "label2";
            // 
            // labelAedRate
            // 
            labelAedRate.AutoSize = true;
            labelAedRate.Location = new Point(12, 36);
            labelAedRate.Name = "labelAedRate";
            labelAedRate.Size = new Size(41, 15);
            labelAedRate.TabIndex = 10;
            labelAedRate.Text = "label3";
            // 
            // rjButton1
            // 
            rjButton1.BackColor = Color.Green;
            rjButton1.BackgroundColor = Color.Green;
            rjButton1.BorderColor = Color.PaleVioletRed;
            rjButton1.BorderRadius = 10;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.Font = new Font("Arial", 9F, FontStyle.Bold);
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(416, 11);
            rjButton1.Name = "rjButton1";
            rjButton1.RightToLeft = RightToLeft.No;
            rjButton1.Size = new Size(94, 28);
            rjButton1.TabIndex = 13;
            rjButton1.Text = "Перевести";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // rjButton2
            // 
            rjButton2.BackColor = Color.Green;
            rjButton2.BackgroundColor = Color.Green;
            rjButton2.BorderColor = Color.PaleVioletRed;
            rjButton2.BorderRadius = 10;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.Font = new Font("Arial", 9F, FontStyle.Bold);
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(416, 43);
            rjButton2.Name = "rjButton2";
            rjButton2.RightToLeft = RightToLeft.No;
            rjButton2.Size = new Size(94, 28);
            rjButton2.TabIndex = 14;
            rjButton2.Text = "История";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += rjButton2_Click;
            // 
            // rjButton3
            // 
            rjButton3.BackColor = Color.Green;
            rjButton3.BackgroundColor = Color.Green;
            rjButton3.BorderColor = Color.PaleVioletRed;
            rjButton3.BorderRadius = 10;
            rjButton3.BorderSize = 0;
            rjButton3.FlatAppearance.BorderSize = 0;
            rjButton3.FlatStyle = FlatStyle.Flat;
            rjButton3.Font = new Font("Arial", 9F, FontStyle.Bold);
            rjButton3.ForeColor = Color.White;
            rjButton3.Location = new Point(416, 77);
            rjButton3.Name = "rjButton3";
            rjButton3.RightToLeft = RightToLeft.No;
            rjButton3.Size = new Size(94, 28);
            rjButton3.TabIndex = 15;
            rjButton3.Text = "Поддержка";
            rjButton3.TextColor = Color.White;
            rjButton3.UseVisualStyleBackColor = false;
            rjButton3.Click += rjButton3_Click;
            // 
            // rjButton4
            // 
            rjButton4.BackColor = Color.Green;
            rjButton4.BackgroundColor = Color.Green;
            rjButton4.BorderColor = Color.PaleVioletRed;
            rjButton4.BorderRadius = 10;
            rjButton4.BorderSize = 0;
            rjButton4.FlatAppearance.BorderSize = 0;
            rjButton4.FlatStyle = FlatStyle.Flat;
            rjButton4.Font = new Font("Arial", 9F, FontStyle.Bold);
            rjButton4.ForeColor = Color.White;
            rjButton4.Location = new Point(416, 111);
            rjButton4.Name = "rjButton4";
            rjButton4.RightToLeft = RightToLeft.No;
            rjButton4.Size = new Size(94, 28);
            rjButton4.TabIndex = 16;
            rjButton4.Text = "Накоп. счет";
            rjButton4.TextColor = Color.White;
            rjButton4.UseVisualStyleBackColor = false;
            rjButton4.Click += rjButton4_Click;
            // 
            // rjButton5
            // 
            rjButton5.BackColor = Color.Green;
            rjButton5.BackgroundColor = Color.Green;
            rjButton5.BorderColor = Color.PaleVioletRed;
            rjButton5.BorderRadius = 10;
            rjButton5.BorderSize = 0;
            rjButton5.FlatAppearance.BorderSize = 0;
            rjButton5.FlatStyle = FlatStyle.Flat;
            rjButton5.Font = new Font("Arial", 9F, FontStyle.Bold);
            rjButton5.ForeColor = Color.White;
            rjButton5.Location = new Point(416, 145);
            rjButton5.Name = "rjButton5";
            rjButton5.RightToLeft = RightToLeft.No;
            rjButton5.Size = new Size(94, 28);
            rjButton5.TabIndex = 17;
            rjButton5.Text = "Настройки";
            rjButton5.TextColor = Color.White;
            rjButton5.UseVisualStyleBackColor = false;
            rjButton5.Click += rjButton5_Click;
            // 
            // rjButton6
            // 
            rjButton6.BackColor = Color.Green;
            rjButton6.BackgroundColor = Color.Green;
            rjButton6.BorderColor = Color.PaleVioletRed;
            rjButton6.BorderRadius = 10;
            rjButton6.BorderSize = 0;
            rjButton6.FlatAppearance.BorderSize = 0;
            rjButton6.FlatStyle = FlatStyle.Flat;
            rjButton6.Font = new Font("Arial", 9F, FontStyle.Bold);
            rjButton6.ForeColor = Color.White;
            rjButton6.Location = new Point(12, 261);
            rjButton6.Name = "rjButton6";
            rjButton6.RightToLeft = RightToLeft.No;
            rjButton6.Size = new Size(94, 28);
            rjButton6.TabIndex = 18;
            rjButton6.Text = "Выход";
            rjButton6.TextColor = Color.White;
            rjButton6.UseVisualStyleBackColor = false;
            rjButton6.Click += rjButton6_Click;
            // 
            // rjButton7
            // 
            rjButton7.BackColor = Color.Green;
            rjButton7.BackgroundColor = Color.Green;
            rjButton7.BorderColor = Color.PaleVioletRed;
            rjButton7.BorderRadius = 10;
            rjButton7.BorderSize = 0;
            rjButton7.FlatAppearance.BorderSize = 0;
            rjButton7.FlatStyle = FlatStyle.Flat;
            rjButton7.Font = new Font("Arial", 9F, FontStyle.Bold);
            rjButton7.ForeColor = Color.White;
            rjButton7.Location = new Point(416, 179);
            rjButton7.Name = "rjButton7";
            rjButton7.RightToLeft = RightToLeft.No;
            rjButton7.Size = new Size(94, 28);
            rjButton7.TabIndex = 19;
            rjButton7.Text = "Новости";
            rjButton7.TextColor = Color.White;
            rjButton7.UseVisualStyleBackColor = false;
            rjButton7.Click += rjButton7_Click;
            // 
            // AccountForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            BackColor = Color.White;
            ClientSize = new Size(522, 301);
            Controls.Add(rjButton7);
            Controls.Add(rjButton6);
            Controls.Add(rjButton5);
            Controls.Add(rjButton4);
            Controls.Add(rjButton3);
            Controls.Add(rjButton2);
            Controls.Add(rjButton1);
            Controls.Add(labelAedRate);
            Controls.Add(labelEurRate);
            Controls.Add(labelUsdRate);
            Controls.Add(labelBalance);
            Controls.Add(labelWelcome);
            Font = new Font("Arial", 9F, FontStyle.Bold);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AccountForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Профиль";
            Load += AccountForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelWelcome;
        private Label labelBalance;
        private Label labelUsdRate;
        private Label labelEurRate;
        private Label labelAedRate;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJButton rjButton2;
        private CustomControls.RJControls.RJButton rjButton3;
        private CustomControls.RJControls.RJButton rjButton4;
        private CustomControls.RJControls.RJButton rjButton5;
        private CustomControls.RJControls.RJButton rjButton6;
        private CustomControls.RJControls.RJButton rjButton7;
    }
}