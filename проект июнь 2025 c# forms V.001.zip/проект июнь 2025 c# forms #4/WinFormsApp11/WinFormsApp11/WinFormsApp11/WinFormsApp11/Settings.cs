﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class Settings : Form
    {
        private UserManager userManager;

        public Settings()
        {
            InitializeComponent();
            userManager = new UserManager();
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            string oldUsername = txtOldUsername.Text.Trim();
            string newUsername = txtNewUsername.Text.Trim();
            string newPassword = txtNewPassword.Text;

            if (string.IsNullOrEmpty(oldUsername) || string.IsNullOrEmpty(newUsername) || string.IsNullOrEmpty(newPassword))
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Пожалуйста, заполните все поля.";
                return;
            }

            var user = userManager.Users.FirstOrDefault(u => u.Username == oldUsername);
            if (user == null)
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Пользователь с таким именем не найден.";
                return;
            }

            if (oldUsername != newUsername && userManager.Users.Any(u => u.Username == newUsername))
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Новое имя пользователя уже занято.";
                return;
            }

            user.Username = newUsername;
            user.Password = userManager.EncryptPassword(newPassword, "MySecretKey");

            userManager.SaveUsers();

            lblStatus.ForeColor = Color.Green;
            lblStatus.Text = "Данные пользователя успешно обновлены.";
        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            string oldUsername = txtOldUsername.Text.Trim();
            string newUsername = txtNewUsername.Text.Trim();
            string newPassword = txtNewPassword.Text;

            if (string.IsNullOrEmpty(oldUsername) || string.IsNullOrEmpty(newUsername) || string.IsNullOrEmpty(newPassword))
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Пожалуйста, заполните все поля.";
                return;
            }

            var user = userManager.Users.FirstOrDefault(u => u.Username == oldUsername);
            if (user == null)
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Пользователь с таким именем не найден.";
                return;
            }

            if (oldUsername != newUsername && userManager.Users.Any(u => u.Username == newUsername))
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Новое имя пользователя уже занято.";
                return;
            }

            user.Username = newUsername;
            user.Password = userManager.EncryptPassword(newPassword, "MySecretKey");

            userManager.SaveUsers();

            lblStatus.ForeColor = Color.Green;
            lblStatus.Text = "Данные пользователя успешно обновлены.";
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

