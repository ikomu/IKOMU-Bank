﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class Story : Form
    {
        private User currentUser;
        private TransactionManager transactionManager;

        private ListView listViewTransactions;

        public Story(User user, TransactionManager transactionManager)
        {
            InitializeComponent();

            this.currentUser = user ?? throw new ArgumentNullException(nameof(user));
            this.transactionManager = transactionManager ?? throw new ArgumentNullException(nameof(transactionManager));

            this.Text = $"История переводов пользователя {currentUser.Username}";

            InitializeListView();
            LoadTransactions();
        }

        private void InitializeListView()
        {
            listViewTransactions = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };

            listViewTransactions.Columns.Add("Дата и время", 180);
            listViewTransactions.Columns.Add("Описание", 230);
            listViewTransactions.Columns.Add("Сумма", 225, HorizontalAlignment.Right);

            this.Controls.Add(listViewTransactions);
        }

        private void LoadTransactions()
        {
            var userTransactions = transactionManager.GetUserTransactions(currentUser.Username);

            listViewTransactions.Items.Clear();

            foreach (var tx in userTransactions)
            {
                var item = new ListViewItem(tx.Date.ToString("yyyy-MM-dd HH:mm:ss"));
                item.SubItems.Add(tx.Description);

                string amountStr = (tx.Amount >= 0 ? "+" : "") + tx.Amount.ToString("C");
                var amountSubItem = item.SubItems.Add(amountStr);
                amountSubItem.ForeColor = tx.Amount >= 0 ? Color.Green : Color.Red;

                listViewTransactions.Items.Add(item);
            }
        }
    }
}
