﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class Perevod : Form
    {
        private UserManager userManager;

        public Perevod()
        {
            InitializeComponent();
            userManager = new UserManager();
        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {
            string fromUsername = txtFromUsername.Text.Trim();
            string toUsername = txtToUsername.Text.Trim();
            string amountText = txtAmount.Text.Trim();

            if (string.IsNullOrEmpty(fromUsername) || string.IsNullOrEmpty(toUsername) || string.IsNullOrEmpty(amountText))
            {
                lblResult.Text = "Пожалуйста, заполните все поля.";
                return;
            }

            if (!decimal.TryParse(amountText, out decimal amount))
            {
                lblResult.Text = "Некорректная сумма.";
                return;
            }

            bool success = userManager.Transfer(fromUsername, toUsername, amount, out string errorMessage);

            if (success)
            {
                lblResult.Text = $"Перевод {amount} от {fromUsername} к {toUsername} выполнен успешно.";
            }
            else
            {
                lblResult.Text = "Ошибка: " + errorMessage;
            }
        }
    }
}
