﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp11
{
    public class Transaction
    {
        public string Username { get; set; }
        public decimal Amount { get; set; } // + или -
        public DateTime Date { get; set; }
        public string Description { get; set; }

        public override string ToString()
        {
            string sign = Amount >= 0 ? "+" : "";
            return $"{Date:G} | {sign}{Amount:C} | {Description}";
        }
    }
}
