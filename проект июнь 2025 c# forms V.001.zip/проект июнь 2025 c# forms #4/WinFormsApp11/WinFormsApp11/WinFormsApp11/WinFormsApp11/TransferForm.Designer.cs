﻿namespace WinFormsApp11
{
    partial class TransferForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TransferForm));
            textBoxRecipientUsername = new TextBox();
            textBoxTransferAmount = new TextBox();
            labelTransferStatus = new Label();
            textBoxSenderUsername = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            rjButton1 = new CustomControls.RJControls.RJButton();
            rjButton2 = new CustomControls.RJControls.RJButton();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // textBoxRecipientUsername
            // 
            textBoxRecipientUsername.Location = new Point(12, 41);
            textBoxRecipientUsername.Name = "textBoxRecipientUsername";
            textBoxRecipientUsername.Size = new Size(211, 23);
            textBoxRecipientUsername.TabIndex = 0;
            // 
            // textBoxTransferAmount
            // 
            textBoxTransferAmount.Location = new Point(12, 70);
            textBoxTransferAmount.Name = "textBoxTransferAmount";
            textBoxTransferAmount.Size = new Size(211, 23);
            textBoxTransferAmount.TabIndex = 1;
            // 
            // labelTransferStatus
            // 
            labelTransferStatus.AutoSize = true;
            labelTransferStatus.Location = new Point(12, 171);
            labelTransferStatus.Name = "labelTransferStatus";
            labelTransferStatus.Size = new Size(95, 15);
            labelTransferStatus.TabIndex = 3;
            labelTransferStatus.Text = "статус перевода";
            // 
            // textBoxSenderUsername
            // 
            textBoxSenderUsername.Location = new Point(12, 12);
            textBoxSenderUsername.Name = "textBoxSenderUsername";
            textBoxSenderUsername.Size = new Size(211, 23);
            textBoxSenderUsername.TabIndex = 4;
            textBoxSenderUsername.UseWaitCursor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Location = new Point(111, 15);
            label1.Name = "label1";
            label1.Size = new Size(103, 15);
            label1.TabIndex = 6;
            label1.Text = "Имя отправителя";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Location = new Point(116, 44);
            label2.Name = "label2";
            label2.Size = new Size(98, 15);
            label2.TabIndex = 7;
            label2.Text = "Имя получателя";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Location = new Point(169, 73);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 8;
            label3.Text = "Сумма";
            // 
            // rjButton1
            // 
            rjButton1.BackColor = Color.Green;
            rjButton1.BackgroundColor = Color.Green;
            rjButton1.BorderColor = Color.PaleVioletRed;
            rjButton1.BorderRadius = 10;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(12, 99);
            rjButton1.Name = "rjButton1";
            rjButton1.RightToLeft = RightToLeft.No;
            rjButton1.Size = new Size(95, 28);
            rjButton1.TabIndex = 14;
            rjButton1.Text = "Перевести";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // rjButton2
            // 
            rjButton2.BackColor = Color.Green;
            rjButton2.BackgroundColor = Color.Green;
            rjButton2.BorderColor = Color.PaleVioletRed;
            rjButton2.BorderRadius = 10;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(354, 155);
            rjButton2.Name = "rjButton2";
            rjButton2.RightToLeft = RightToLeft.No;
            rjButton2.Size = new Size(94, 28);
            rjButton2.TabIndex = 15;
            rjButton2.Text = "Назад";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += rjButton2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(229, -30);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(253, 169);
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            // 
            // TransferForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(460, 195);
            Controls.Add(pictureBox1);
            Controls.Add(rjButton2);
            Controls.Add(rjButton1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxSenderUsername);
            Controls.Add(labelTransferStatus);
            Controls.Add(textBoxTransferAmount);
            Controls.Add(textBoxRecipientUsername);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TransferForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Переводы";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxRecipientUsername;
        private TextBox textBoxTransferAmount;
        private Label labelTransferStatus;
        private TextBox textBoxSenderUsername;
        private Label label1;
        private Label label2;
        private Label label3;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJButton rjButton2;
        private PictureBox pictureBox1;
    }
}