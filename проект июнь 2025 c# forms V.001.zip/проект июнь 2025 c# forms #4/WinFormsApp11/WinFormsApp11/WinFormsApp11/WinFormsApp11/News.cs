﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class News : Form
    {
        private const string JsonFilePath = "items.json";
        private List<string> items = new List<string>();

        public News()
        {
            InitializeComponent();
            LoadItemsFromFile();
            UpdateListBox();
        }

        private void LoadItemsFromFile()
        {
            if (File.Exists(JsonFilePath))
            {
                try
                {
                    string json = File.ReadAllText(JsonFilePath);
                    items = JsonConvert.DeserializeObject<List<string>>(json) ?? new List<string>();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке файла: " + ex.Message);
                    items = new List<string>();
                }
            }
            else
            {
                // Файл не существует — создаём с начальным текстом
                items = new List<string> { "Текст" };
                try
                {
                    string json = JsonConvert.SerializeObject(items, Formatting.Indented);
                    File.WriteAllText(JsonFilePath, json);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при создании файла: " + ex.Message);
                }
            }
        }


        private void UpdateListBox()
        {
            listBoxItems.Items.Clear();
            foreach (var item in items)
            {
                listBoxItems.Items.Add(item);
            }
        }
    }
}

