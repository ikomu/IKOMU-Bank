﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class BalancePlus : Form
    {
        private User currentUser;
        private UserManager userManager;

        private System.Windows.Forms.Timer timerNormal;
        private System.Windows.Forms.Timer timerPromo;

        private bool promoActive = false;

        public BalancePlus(User user, UserManager userManager)
        {
            InitializeComponent();

            if (userManager == null) throw new ArgumentNullException(nameof(userManager));
            if (user == null) throw new ArgumentNullException(nameof(user));

            this.userManager = userManager;

            // Получаем ссылку на пользователя из списка, чтобы работать с оригиналом
            this.currentUser = userManager.Users.FirstOrDefault(u => u.Username == user.Username);
            if (this.currentUser == null)
            {
                // Если вдруг пользователя нет — добавляем нового (по необходимости)
                this.currentUser = user;
                userManager.Users.Add(this.currentUser);
                userManager.SaveUsers();
            }

            UpdateBalancesUI();

            timerNormal = new System.Windows.Forms.Timer { Interval = 10000 }; // 10 секунд
            timerNormal.Tick += TimerNormal_Tick;
            timerNormal.Start();

            timerPromo = new System.Windows.Forms.Timer { Interval = 8000 }; // 8 секунд
            timerPromo.Tick += TimerPromo_Tick;

            labelStatus.Text = "";
        }

        private void UpdateBalancesUI()
        {
            labelBalance.Text = $"Основной баланс: {currentUser.Balance:C}";
            labelAccumulated.Text = $"Накопительный баланс: {currentUser.AccumulatedBalance:C}";
        }

        private void TimerNormal_Tick(object sender, EventArgs e)
        {
            currentUser.AccumulatedBalance += 0.01m;
            UpdateBalancesUI();
            SetStatus("+0.01 к накопительному балансу (каждые 10 сек)", Color.Green);
            userManager.SaveUsers(); // Сохраняем изменения
        }

        private void TimerPromo_Tick(object sender, EventArgs e)
        {
            currentUser.AccumulatedBalance += 0.02m;
            UpdateBalancesUI();
            SetStatus("+0.02 к накопительному балансу (промокод активен)", Color.Blue);
            userManager.SaveUsers(); // Сохраняем изменения
        }

        private void rjButton1_Click(object sender, EventArgs e) // заменяет btnDeposit_Click_1
        {
            if (decimal.TryParse(txtAmount.Text, out decimal amount))
            {
                if (amount <= 0)
                {
                    SetStatus("Введите положительную сумму", Color.Red);
                    return;
                }
                if (currentUser.Balance < amount)
                {
                    SetStatus("Недостаточно средств на основном счёте", Color.Red);
                    return;
                }

                currentUser.Balance -= amount;
                currentUser.AccumulatedBalance += amount;
                UpdateBalancesUI();
                SetStatus($"Переведено {amount:C} на накопительный счёт", Color.Green);
                userManager.SaveUsers();
            }
            else
            {
                SetStatus("Неверный формат суммы", Color.Red);
            }
        }

        private void rjButton2_Click(object sender, EventArgs e) // заменяет btnWithdraw_Click_1
        {
            if (decimal.TryParse(txtAmount.Text, out decimal amount))
            {
                if (amount <= 0)
                {
                    SetStatus("Введите положительную сумму", Color.Red);
                    return;
                }
                if (currentUser.AccumulatedBalance < amount)
                {
                    SetStatus("Недостаточно средств на накопительном счёте", Color.Red);
                    return;
                }

                currentUser.AccumulatedBalance -= amount;
                currentUser.Balance += amount;
                UpdateBalancesUI();
                SetStatus($"Переведено {amount:C} на основной счёт", Color.Green);
                userManager.SaveUsers();
            }
            else
            {
                SetStatus("Неверный формат суммы", Color.Red);
            }
        }

        private void rjButton3_Click(object sender, EventArgs e) // заменяет btnApplyPromo_Click_1
        {
            string promoCode = txtPromoCode.Text.Trim();

            if (promoActive)
            {
                SetStatus("Промокод уже активирован", Color.Orange);
                return;
            }

            if (promoCode == "IKOMU") // Ваш промокод
            {
                promoActive = true;
                timerPromo.Start();
                SetStatus("Промокод активирован! +0.02 каждые 8 секунд.", Color.Blue);
            }
            else
            {
                SetStatus("Неверный промокод", Color.Red);
            }
        }

        private void SetStatus(string message, Color color)
        {
            labelStatus.ForeColor = color;
            labelStatus.Text = message;
        }

        private void BalancePlus_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Просто сохраняем пользователей — currentUser уже в списке и обновлён
            userManager.SaveUsers();
        }

        private void labelStatus_Click(object sender, EventArgs e)
        {
            // Можно оставить пустым или удалить, если не используется
        }

        private void rjButton6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
