﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace WinFormsApp11
{
    public class UserManager
    {
        private const string FilePath = "users.json";
        private const string EncryptionKey = "MySecretKey";

        public List<User> Users { get; private set; } = new List<User>();

        public UserManager()
        {
            LoadUsers();
            if (!Users.Any(u => u.Username == "admin"))
            {
                AddUser(new User { Username = "admin", Password = "admin123", Role = "Admin", Balance = 0m });
            }
        }

        public void LoadUsers()
        {
            if (File.Exists(FilePath))
            {
                try
                {
                    string json = File.ReadAllText(FilePath);
                    var loadedUsers = JsonSerializer.Deserialize<List<User>>(json);

                    if (loadedUsers != null)
                    {
                        Users = loadedUsers;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при загрузке пользователей: {ex.Message}");
                    Users = new List<User>();
                }
            }
        }

        public void SaveUsers()
        {
            string json = JsonSerializer.Serialize(Users, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(FilePath, json);
        }

        public bool AddUser(User user)
        {
            if (Users.Any(u => u.Username == user.Username))
            {
                return false;
            }

            user.Password = EncryptPassword(user.Password, EncryptionKey);
            Users.Add(user);
            SaveUsers();
            return true;
        }

        public bool RemoveUser(string username)
        {
            var user = Users.FirstOrDefault(u => u.Username == username);
            if (user != null && user.Role != "Admin")
            {
                Users.Remove(user);
                SaveUsers();
                return true;
            }
            return false;
        }

        public bool ValidateUser(string username, string password)
        {
            var user = Users.FirstOrDefault(u => u.Username == username);
            if (user == null)
            {
                return false;
            }

            string decryptedPassword = DecryptPassword(user.Password, EncryptionKey);
            return decryptedPassword == password;
        }

        // Добавленный метод перевода денег
        public bool Transfer(string fromUsername, string toUsername, decimal amount, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (amount <= 0)
            {
                errorMessage = "Сумма перевода должна быть больше нуля.";
                return false;
            }

            var fromUser = Users.FirstOrDefault(u => u.Username == fromUsername);
            if (fromUser == null)
            {
                errorMessage = "Пользователь-отправитель не найден.";
                return false;
            }

            var toUser = Users.FirstOrDefault(u => u.Username == toUsername);
            if (toUser == null)
            {
                errorMessage = "Пользователь-получатель не найден.";
                return false;
            }

            if (fromUser.Balance < amount)
            {
                errorMessage = "Недостаточно средств на балансе отправителя.";
                return false;
            }

            fromUser.Balance -= amount;
            toUser.Balance += amount;

            SaveUsers();
            return true;
        }

        public string EncryptPassword(string password, string key)
        {
            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);
            byte[] resultBytes = new byte[passwordBytes.Length];

            for (int i = 0; i < passwordBytes.Length; i++)
            {
                resultBytes[i] = (byte)(passwordBytes[i] ^ keyBytes[i % keyBytes.Length]);
            }

            return Convert.ToBase64String(resultBytes);
        }

        private static string DecryptPassword(string encryptedPassword, string key)
        {
            byte[] encryptedBytes = Convert.FromBase64String(encryptedPassword);
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);
            byte[] resultBytes = new byte[encryptedBytes.Length];

            for (int i = 0; i < encryptedBytes.Length; i++)
            {
                resultBytes[i] = (byte)(encryptedBytes[i] ^ keyBytes[i % keyBytes.Length]);
            }

            return Encoding.UTF8.GetString(resultBytes);
        }
    }
}
