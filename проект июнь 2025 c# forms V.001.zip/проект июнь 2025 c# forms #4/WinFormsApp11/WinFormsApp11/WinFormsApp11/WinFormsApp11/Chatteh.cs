﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class Chatteh : Form
    {
        private int userMessageCount = 0;
        private bool isWaitingResponse = false;

        public Chatteh()
        {
            InitializeComponent();
        }

        private async void rjButton1_Click(object sender, EventArgs e)
        {
            if (isWaitingResponse) return; // Запретить отправлять пока ждём ответ

            string userText = txtInput.Text.Trim();
            if (string.IsNullOrEmpty(userText)) return;

            if (userMessageCount >= 5)
            {
                AppendChat("Система", "Вы заблокированы и не можете писать.");
                txtInput.Enabled = false;
                btnSend.Enabled = false;
                return;
            }

            AppendChat("Вы", userText);
            txtInput.Clear();

            userMessageCount++;
            isWaitingResponse = true;

            await Task.Delay(5000); // Ждём 5 секунд

            if (userMessageCount == 1)
            {
                AppendChat("Поддержка", "Это ваши проблемы?");
            }
            else if (userMessageCount == 2)
            {
                AppendChat("Поддержка", "Нету больше смысла разговаривать");

            }
            else if (userMessageCount == 3)
            {
                AppendChat("Поддержка", "Ещё раз и я заблокирую!");

            }
            else if (userMessageCount >= 4)
            {
                AppendChat("Поддержка", "Вы заблокированы и не можете писать.");
                txtInput.Enabled = false;
                btnSend.Enabled = false;
            }
            else
            {
                AppendChat("Поддержка", "...");
            }

            isWaitingResponse = false;
        }

        private void AppendChat(string sender, string message)
        {
            txtChat.AppendText($"{sender}: {message}{Environment.NewLine}");
        }

        private void rjButton6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
