﻿namespace WinFormsApp11
{
    partial class BalancePlus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BalancePlus));
            labelBalance = new Label();
            labelAccumulated = new Label();
            labelStatus = new Label();
            txtAmount = new TextBox();
            txtPromoCode = new TextBox();
            label2 = new Label();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            rjButton6 = new CustomControls.RJControls.RJButton();
            rjButton1 = new CustomControls.RJControls.RJButton();
            rjButton2 = new CustomControls.RJControls.RJButton();
            rjButton3 = new CustomControls.RJControls.RJButton();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // labelBalance
            // 
            labelBalance.AutoSize = true;
            labelBalance.Location = new Point(215, 9);
            labelBalance.Name = "labelBalance";
            labelBalance.Size = new Size(72, 15);
            labelBalance.TabIndex = 1;
            labelBalance.Text = "Баланс осн.";
            // 
            // labelAccumulated
            // 
            labelAccumulated.AutoSize = true;
            labelAccumulated.Location = new Point(215, 35);
            labelAccumulated.Name = "labelAccumulated";
            labelAccumulated.Size = new Size(138, 15);
            labelAccumulated.TabIndex = 2;
            labelAccumulated.Text = "Накопительный баланс";
            // 
            // labelStatus
            // 
            labelStatus.AutoSize = true;
            labelStatus.Location = new Point(215, 66);
            labelStatus.Name = "labelStatus";
            labelStatus.Size = new Size(43, 15);
            labelStatus.TabIndex = 3;
            labelStatus.Text = "Статус";
            labelStatus.Click += labelStatus_Click;
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(12, 9);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(197, 23);
            txtAmount.TabIndex = 4;
            // 
            // txtPromoCode
            // 
            txtPromoCode.Location = new Point(12, 176);
            txtPromoCode.Name = "txtPromoCode";
            txtPromoCode.Size = new Size(197, 23);
            txtPromoCode.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Location = new Point(128, 179);
            label2.Name = "label2";
            label2.Size = new Size(65, 15);
            label2.TabIndex = 10;
            label2.Text = "Промокод";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Location = new Point(158, 12);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 11;
            label3.Text = "Сумма";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(253, 94);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 134);
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // rjButton6
            // 
            rjButton6.BackColor = Color.Green;
            rjButton6.BackgroundColor = Color.Green;
            rjButton6.BorderColor = Color.PaleVioletRed;
            rjButton6.BorderRadius = 10;
            rjButton6.BorderSize = 0;
            rjButton6.FlatAppearance.BorderSize = 0;
            rjButton6.FlatStyle = FlatStyle.Flat;
            rjButton6.ForeColor = Color.White;
            rjButton6.Location = new Point(404, 200);
            rjButton6.Name = "rjButton6";
            rjButton6.RightToLeft = RightToLeft.No;
            rjButton6.Size = new Size(94, 28);
            rjButton6.TabIndex = 20;
            rjButton6.Text = "Назад";
            rjButton6.TextColor = Color.White;
            rjButton6.UseVisualStyleBackColor = false;
            rjButton6.Click += rjButton6_Click;
            // 
            // rjButton1
            // 
            rjButton1.BackColor = Color.Green;
            rjButton1.BackgroundColor = Color.Green;
            rjButton1.BorderColor = Color.PaleVioletRed;
            rjButton1.BorderRadius = 10;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(12, 69);
            rjButton1.Name = "rjButton1";
            rjButton1.RightToLeft = RightToLeft.No;
            rjButton1.Size = new Size(194, 28);
            rjButton1.TabIndex = 21;
            rjButton1.Text = "Перевод с основ. на накопит.";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // rjButton2
            // 
            rjButton2.BackColor = Color.Green;
            rjButton2.BackgroundColor = Color.Green;
            rjButton2.BorderColor = Color.PaleVioletRed;
            rjButton2.BorderRadius = 10;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(12, 35);
            rjButton2.Name = "rjButton2";
            rjButton2.RightToLeft = RightToLeft.No;
            rjButton2.Size = new Size(194, 28);
            rjButton2.TabIndex = 22;
            rjButton2.Text = "Перевод с накопит. на основ.";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += rjButton2_Click;
            // 
            // rjButton3
            // 
            rjButton3.BackColor = Color.Green;
            rjButton3.BackgroundColor = Color.Green;
            rjButton3.BorderColor = Color.PaleVioletRed;
            rjButton3.BorderRadius = 10;
            rjButton3.BorderSize = 0;
            rjButton3.FlatAppearance.BorderSize = 0;
            rjButton3.FlatStyle = FlatStyle.Flat;
            rjButton3.ForeColor = Color.White;
            rjButton3.Location = new Point(12, 205);
            rjButton3.Name = "rjButton3";
            rjButton3.RightToLeft = RightToLeft.No;
            rjButton3.Size = new Size(197, 28);
            rjButton3.TabIndex = 23;
            rjButton3.Text = "Активировать";
            rjButton3.TextColor = Color.White;
            rjButton3.UseVisualStyleBackColor = false;
            rjButton3.Click += rjButton3_Click;
            // 
            // BalancePlus
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(510, 240);
            Controls.Add(rjButton3);
            Controls.Add(rjButton2);
            Controls.Add(rjButton1);
            Controls.Add(rjButton6);
            Controls.Add(pictureBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtPromoCode);
            Controls.Add(txtAmount);
            Controls.Add(labelStatus);
            Controls.Add(labelAccumulated);
            Controls.Add(labelBalance);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "BalancePlus";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Накопительный счет";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label labelBalance;
        private Label labelAccumulated;
        private Label labelStatus;
        private TextBox txtAmount;
        private TextBox txtPromoCode;
        private Label label2;
        private Label label3;
        private PictureBox pictureBox1;
        private CustomControls.RJControls.RJButton rjButton6;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJButton rjButton2;
        private CustomControls.RJControls.RJButton rjButton3;
    }
}