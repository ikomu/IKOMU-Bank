using System;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class Form1 : Form
    {
        private UserManager userManager = new UserManager();

        public Form1()
        {
            InitializeComponent();
            labelStatus.Text = string.Empty;
            //    buttonLogin2.Click += buttonLogin_Click;
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            string username = textBoxUsername.Text.Trim();
            string password = textBoxPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Пожалуйста, введите имя пользователя и пароль.");
                return;
            }

            if (userManager.AddUser(new User { Username = username, Password = password, Role = "User" }))
            {
                MessageBox.Show("Аккаунт успешно создан!");
                OpenAccountForm(username);
            }
            else
            {
                MessageBox.Show("Пользователь с таким именем уже существует.");
            }
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string username = textBoxUsername.Text.Trim();
            string password = textBoxPassword.Text;

            Console.WriteLine($"Попытка входа: {username}, {password}");

            if (userManager.ValidateUser(username, password))
            {
                var user = userManager.Users.FirstOrDefault(u => u.Username == username);

                if (user != null && username == "admin")
                {
                    OpenAdminForm();
                }
                else if (user != null)
                {
                    OpenAccountForm(username);
                }
                else
                {
                    MessageBox.Show("Неожиданная ошибка: пользователь найден, но объект пользователя равен null.");
                }

            }
            else
            {
                MessageBox.Show("Неверный логин или пароль.");
            }
        }

        private void OpenAccountForm(string username)
        {
            var user = userManager.Users.FirstOrDefault(u => u.Username == username);
            if (user == null)
            {
                MessageBox.Show("Ошибка: Пользователь не найден.");
                return;
            }

            textBoxUsername.Clear();
            textBoxPassword.Clear();

            this.Hide();
            var accountForm = new AccountForm(user);
            accountForm.FormClosed += (s, args) => this.Show();
            accountForm.Show();
        }

        private void OpenAdminForm()
        {
            textBoxUsername.Clear();
            textBoxPassword.Clear();

            this.Hide();
            var adminForm = new AdminForm(userManager);
            adminForm.FormClosed += (s, args) => this.Show();
            adminForm.Show();
        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            string username = textBoxUsername.Text.Trim();
            string password = textBoxPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Пожалуйста, введите имя пользователя и пароль.");
                return;
            }

            if (userManager.AddUser(new User { Username = username, Password = password, Role = "User" }))
            {
                MessageBox.Show("Аккаунт успешно создан!");
                OpenAccountForm(username);
            }
            else
            {
                MessageBox.Show("Пользователь с таким именем уже существует.");
            }
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            string username = textBoxUsername.Text.Trim();
            string password = textBoxPassword.Text;

            Console.WriteLine($"Попытка входа: {username}, {password}");

            if (userManager.ValidateUser(username, password))
            {
                var user = userManager.Users.FirstOrDefault(u => u.Username == username);

                if (user != null && username == "admin")
                {
                    OpenAdminForm();
                }
                else if (user != null)
                {
                    OpenAccountForm(username);
                }
                else
                {
                    MessageBox.Show("Неожиданная ошибка: пользователь найден, но объект пользователя равен null.");
                }

            }
            else
            {
                MessageBox.Show("Неверный логин или пароль.");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
