﻿using System;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class TransferForm : Form
    {
        private UserManager _userManager;
        private TransactionManager transactionManager;

        public TransferForm(UserManager userManager, TransactionManager transactionManager)
        {
            InitializeComponent();

            _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
            this.transactionManager = transactionManager ?? throw new ArgumentNullException(nameof(transactionManager));
        }

        private void buttonTransfer_Click(object sender, EventArgs e)
        {
            string senderUsername = textBoxSenderUsername.Text.Trim();
            string recipientUsername = textBoxRecipientUsername.Text.Trim();
            string amountText = textBoxTransferAmount.Text.Trim();

            if (string.IsNullOrEmpty(senderUsername))
            {
                labelTransferStatus.Text = "Введите логин отправителя.";
                return;
            }

            if (string.IsNullOrEmpty(recipientUsername))
            {
                labelTransferStatus.Text = "Введите логин получателя.";
                return;
            }

            if (senderUsername.Equals(recipientUsername, StringComparison.OrdinalIgnoreCase))
            {
                labelTransferStatus.Text = "Нельзя переводить самому себе.";
                return;
            }

            if (!decimal.TryParse(amountText, out decimal amount) || amount <= 0)
            {
                labelTransferStatus.Text = "Введите корректную сумму перевода.";
                return;
            }

            bool success = _userManager.Transfer(senderUsername, recipientUsername, amount, out string errorMessage);

            if (success)
            {
                transactionManager.AddTransaction(senderUsername, -amount, $"Перевод к {recipientUsername}");
                transactionManager.AddTransaction(recipientUsername, amount, $"Перевод от {senderUsername}");

                labelTransferStatus.Text = $"Перевод {amount:C} от {senderUsername} к {recipientUsername} выполнен.";
            }
            else
            {
                labelTransferStatus.Text = $"Ошибка перевода: {errorMessage}";
            }
        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            string senderUsername = textBoxSenderUsername.Text.Trim();
            string recipientUsername = textBoxRecipientUsername.Text.Trim();
            string amountText = textBoxTransferAmount.Text.Trim();

            if (string.IsNullOrEmpty(senderUsername))
            {
                labelTransferStatus.ForeColor = System.Drawing.Color.Red;
                labelTransferStatus.Text = "Введите логин отправителя.";
                return;
            }

            if (string.IsNullOrEmpty(recipientUsername))
            {
                labelTransferStatus.ForeColor = System.Drawing.Color.Red;
                labelTransferStatus.Text = "Введите логин получателя.";
                return;
            }

            if (senderUsername.Equals(recipientUsername, StringComparison.OrdinalIgnoreCase))
            {
                labelTransferStatus.ForeColor = System.Drawing.Color.Red;
                labelTransferStatus.Text = "Нельзя переводить самому себе.";
                return;
            }

            if (!decimal.TryParse(amountText, out decimal amount) || amount <= 0)
            {
                labelTransferStatus.ForeColor = System.Drawing.Color.Red;
                labelTransferStatus.Text = "Введите корректную сумму перевода.";
                return;
            }

            bool success = _userManager.Transfer(senderUsername, recipientUsername, amount, out string errorMessage);

            if (success)
            {
                transactionManager.AddTransaction(senderUsername, -amount, $"Перевод к {recipientUsername}");
                transactionManager.AddTransaction(recipientUsername, amount, $"Перевод от {senderUsername}");

                labelTransferStatus.ForeColor = System.Drawing.Color.Green;
                labelTransferStatus.Text = $"Перевод {amount:C} от {senderUsername} к {recipientUsername} выполнен.";
            }
            else
            {
                labelTransferStatus.ForeColor = System.Drawing.Color.Red;
                labelTransferStatus.Text = $"Ошибка перевода: {errorMessage}";
            }
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
